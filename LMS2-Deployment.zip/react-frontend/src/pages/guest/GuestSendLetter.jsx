
import React, { useState, useRef, useEffect } from "react";
import {
    FileText,
    Send,
    Trash2,
    Upload,
    Calendar as CalendarIcon,
    User,
    Hash,
    MessageSquare,
    Check,
    Plus,
    X as XIcon,
    AlertCircle,
    Menu
} from "lucide-react";
import Sidebar from "../../components/Sidebar";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import attachmentService from "../../services/attachmentService";
import letterService from "../../services/letterService";
import axios from "axios";
import SuccessModal from "../../components/SuccessModal";
import useAccess from "../../hooks/useAccess";

export default function GuestSendLetter() {
    const { user, logout, layoutStyle, isMobileMenuOpen, setIsMobileMenuOpen, isGuest } = useAuth();
    const access = useAccess();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        regarding: "",
        encoder: "",
        senders: [""],
        refAttachmentId: "",
    });
    const [attachments, setAttachments] = useState([]);
    const [refAttachments, setRefAttachments] = useState([]);
    const [referenceNo, setReferenceNo] = useState("Generating...");
    const [suggestions, setSuggestions] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [activeSenderIndex, setActiveSenderIndex] = useState(null); // numeric for senders, 'encoder' for encoder
    const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
    const [isExitModalOpen, setIsExitModalOpen] = useState(false);
    const fileInputRef = useRef(null);
    const suggestionRef = useRef(null);
    const canField = access?.canField || (() => true);
    const canSenderField = canField("guest-send-letter", "sender_field");
    const canEncoderField = canField("guest-send-letter", "encoder_field");
    const canSummaryField = canField("guest-send-letter", "summary_field");
    const canAttachmentSelector = canField("guest-send-letter", "attachment_selector");
    const canAttachmentUpload = canField("guest-send-letter", "attachment_upload");
    const canSubmit = canField("guest-send-letter", "submit_button");
    const canClear = canField("guest-send-letter", "clear_button");
    const today = new Date().toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
    });
    useEffect(() => {
        const fetchRefs = async () => {
            try {
                const data = await attachmentService.getAll();
                setRefAttachments(data);

                // Fetch next Reference No
                const preview = await letterService.getPreviewIds();
                if (preview && preview.lms_id) {
                    setReferenceNo(preview.lms_id);
                }
            } catch (err) {
                console.error("Failed to fetch ref attachments or IDs:", err);
            }
        };
        fetchRefs();
    }, []);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (suggestionRef.current && !suggestionRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const fetchSuggestions = async (query) => {
        if (!query || query.length < 2) {
            setSuggestions([]);
            setShowSuggestions(false);
            return;
        }
        try {
            const response = await axios.get(`${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/persons/search?query=${query}`);
            setSuggestions(response.data);
            setShowSuggestions(response.data.length > 0);
        } catch (error) {
            console.error("Error fetching suggestions:", error);
        }
    };

    const validateFormat = (text) => {
        if (!text) return true; // Let required validator handle empty
        const regex = /^[A-Z,\s.]+$/i; // Allowing characters, spaces, dots, and COMMA
        return regex.test(text) && text.includes(',');
    };

    const handleClear = () => {
        setFormData({
            senders: [""],
            regarding: "",
            encoder: "",
            refAttachmentId: ""
        });
        setAttachments([]);
    };

    const handleSend = async () => {
        const invalidSender = formData.senders.find(s => !s || !validateFormat(s));
        if (invalidSender !== undefined) {
            alert("All Senders must follow the format: LASTNAME, FIRSTNAME");
            return;
        }

        if (!validateFormat(formData.encoder)) {
            alert("Encoder name must follow the format: LASTNAME, FIRSTNAME");
            return;
        }

        if (!formData.regarding) {
            alert("Please enter a summary of the correspondence.");
            return;
        }

        try {
            setLoading(true);
            let scannedCopyPath = null;

            // Determine if digital upload is allowed based on selected refAttachmentId
            const selectedAtt = refAttachments.find(att => String(att.id) === String(formData.refAttachmentId));
            const attName = selectedAtt?.attachment_name?.toLowerCase() || "";
            const isLetterOrPhoto = attName.includes("letter") || attName.includes("photo");

            // 1. If there's a scanned file AND it's a letter/photo, upload the first one as primary scan
            if (isLetterOrPhoto && attachments.length > 0) {
                const formDataUpload = new FormData();
                formDataUpload.append('file', attachments[0]);
                formDataUpload.append('no_record', 'true');
                formDataUpload.append('purpose', 'scanned_copy');

                const response = await axios.post(`${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/attachments/upload`, formDataUpload, {
                    headers: { 'Content-Type': 'multipart/form-data' }
                });
                scannedCopyPath = response.data.file_path;
            }

            // 2. Format the date range for the summary if present (removed, so this block is now empty)
            let dateInfo = "";

            // 3. Save the letter
            await axios.post(`${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/letters`, {
                sender: formData.senders.join('; '),
                encoder: formData.encoder, // Pass typed encoder name for syncing to Persons
                summary: formData.regarding + dateInfo,
                date_received: new Date(),
                global_status: 1, // Incoming
                encoder_id: user?.id,
                letter_type: 'Non-Confidential',
                attachment_id: formData.refAttachmentId || null,
                scanned_copy: scannedCopyPath,
                direction: 'Incoming',
                kind: null, // No kind selection in guest mode
                assigned_dept: "" // No initial process step
            });

            setIsSuccessModalOpen(true);
        } catch (err) {
            console.error("Submission failed:", err);
            alert("Failed to send letter. Check console for details.");
        } finally {
            setLoading(false);
        }
    };

    const handleFileChange = (e) => {
        const selectedFiles = Array.from(e.target.files);
        setAttachments(prev => [...prev, ...selectedFiles]);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        const files = Array.from(e.dataTransfer.files);
        if (files.length > 0) {
            setAttachments(prev => [...prev, ...files]);
        }
    };

    const handlePaste = (e) => {
        const items = (e.clipboardData || e.originalEvent.clipboardData).items;
        const files = [];
        for (let index in items) {
            const item = items[index];
            if (item.kind === 'file') {
                const blob = item.getAsFile();
                if (blob) files.push(blob);
            }
        }
        if (files.length > 0) {
            setAttachments(prev => [...prev, ...files]);
        }
    };

    useEffect(() => {
        window.addEventListener('paste', handlePaste);
        return () => window.removeEventListener('paste', handlePaste);
    }, []);

    const removeAttachment = (index) => {
        setAttachments(prev => prev.filter((_, i) => i !== index));
    };

    const addSender = () => {
        setFormData(prev => ({ ...prev, senders: [...prev.senders, ""] }));
    };

    const removeSender = (index) => {
        if (formData.senders.length <= 1) return;
        setFormData(prev => ({
            ...prev,
            senders: prev.senders.filter((_, i) => i !== index)
        }));
    };

    const updateSender = (index, value) => {
        const newSenders = [...formData.senders];
        newSenders[index] = value;
        setFormData(prev => ({ ...prev, senders: newSenders }));

        setActiveSenderIndex(index);
        fetchSuggestions(value.split(',').pop().trim());
    };

    const selectSuggestion = (name) => {
        if (activeSenderIndex === null) return;

        if (activeSenderIndex === 'encoder') {
            setFormData(prev => ({ ...prev, encoder: name + ', ' }));
        } else {
            const newSenders = [...formData.senders];
            const val = newSenders[activeSenderIndex];
            const parts = val.split(',').map(p => p.trim());
            parts[parts.length - 1] = name;
            newSenders[activeSenderIndex] = parts.filter(p => p !== "").join(', ') + ', ';
            setFormData(prev => ({ ...prev, senders: newSenders }));
        }
        setShowSuggestions(false);
    };

    // Layout-specific styling
    const pageBg = layoutStyle === 'notion' ? 'bg-white dark:bg-[#191919]' : layoutStyle === 'grid' ? 'bg-slate-50' : 'bg-[#F9FAFB] dark:bg-[#0D0D0D]';
    const headerBg = layoutStyle === 'notion' ? 'bg-white dark:bg-[#191919] border-gray-100 dark:border-[#222]' : layoutStyle === 'grid' ? 'bg-white border-slate-100' : 'bg-white dark:bg-[#141414] border-gray-100 dark:border-[#222]';
    const cardBg = layoutStyle === 'notion' ? 'bg-white dark:bg-[#191919] border-gray-100 dark:border-[#222]' : 'bg-white dark:bg-[#141414] border-gray-100 dark:border-[#222]';
    const accentColor = layoutStyle === 'grid' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-[#F6A17B] hover:bg-[#e8946e]';
    const textColor = 'text-slate-900 dark:text-white';
    const subTextColor = 'text-blue-600';
    const inputBg = 'bg-slate-50 dark:bg-white/5 border-slate-50 dark:border-[#333] text-slate-800 dark:text-white';

    // isLoggedIn means a real authenticated user (not a guest)
    const isLoggedIn = !!user?.id && !isGuest;
    const isRegularUser = user?.roleData?.name === 'USER' || user?.role === 'USER';

    return (
        <div className={`flex min-h-screen ${pageBg} font-sans transition-colors duration-300`}>
            {isLoggedIn && <Sidebar />}

            <div className="flex-1 flex flex-col min-w-0">
                {/* Top Header / Status Bar */}
                <header className={`h-16 ${headerBg} border-b px-8 flex items-center justify-between sticky top-0 z-50 shrink-0`}>
                    <div className="flex items-center gap-4">
                        {isLoggedIn && (
                            <button
                                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                                className="lg:hidden p-2.5 bg-slate-100 dark:bg-white/5 rounded-xl text-gray-400"
                            >
                                <Menu className="w-5 h-5" />
                            </button>
                        )}
                        <div className="flex items-center gap-2">
                            <FileText className={`w-4 h-4 ${layoutStyle === 'minimalist' ? 'text-[#1A1A1B] dark:text-white' : 'text-blue-500'}`} />
                            <div>
                                <h1 className="text-[10px] font-black uppercase tracking-widest text-gray-400">Correspondence</h1>
                                <h2 className={`text-sm font-black uppercase tracking-tight ${textColor}`}>{referenceNo}</h2>
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center gap-6">
                        <div className="hidden md:flex flex-col items-end">
                            <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Entry Date</span>
                            <span className={`text-xs font-black ${textColor}`}>{today}</span>
                        </div>
                        {!isLoggedIn && (
                            <div className="flex items-center gap-4">
                                <div className="px-3 py-1 bg-orange-500/10 text-orange-500 text-[10px] font-black uppercase tracking-widest rounded-lg border border-orange-500/20">
                                    Guest Mode
                                </div>
                                <button
                                    onClick={() => setIsExitModalOpen(true)}
                                    className="text-[10px] font-black text-gray-400 hover:text-red-500 uppercase tracking-widest transition-colors"
                                >
                                    Exit
                                </button>
                            </div>
                        )}
                    </div>
                </header>

                <main className="flex-1 p-4 md:p-8 lg:p-16 overflow-y-auto custom-scrollbar">
                    <div className="max-w-screen-2xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-16">

                        {/* Metadata Section */}
                        <div className="lg:col-span-8 space-y-8 md:space-y-12">
                            <section className={`${cardBg} p-8 md:p-16 rounded-[2.5rem] md:rounded-[3.5rem] border shadow-2xl shadow-slate-200/5 space-y-8 md:space-y-12`}>
                                <div className={`flex items-center gap-4 border-b pb-8 ${'border-slate-50 dark:border-[#222]'}`}>
                                    <FileText className={`w-6 h-6 ${subTextColor}`} />
                                    <h2 className={`text-lg font-black uppercase tracking-tight ${textColor}`}>Letter Metadata</h2>
                                </div>

                                <div className="grid grid-cols-1 gap-8">
                                    {/* Sender */}
                                    {canSenderField && <div className="space-y-3">
                                        <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                <User className={`w-3 h-3 ${subTextColor}`} /> Sender Name(LASTNAME, FIRSTNAME)
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <span className="text-[9px] text-red-500 font-black tracking-widest">REQUIRED</span>
                                            </div>
                                        </label>

                                        <div className="space-y-3">
                                            {formData.senders.map((sender, index) => {
                                                const isValid = validateFormat(sender);
                                                return (
                                                    <div key={index} className="relative group">
                                                        <input
                                                            type="text"
                                                            placeholder="Dela Cruz, Juan M."
                                                            value={sender}
                                                            onChange={(e) => updateSender(index, e.target.value)}
                                                            onFocus={() => {
                                                                setActiveSenderIndex(index);
                                                                if (sender.length >= 2) fetchSuggestions(sender.split(',').pop().trim());
                                                            }}
                                                            className={`w-full px-6 py-4 ${inputBg} border-2 rounded-2xl focus:border-orange-500 transition-all text-lg font-bold outline-none ${!isValid && sender ? 'border-red-500/50' : ''}`}
                                                        />

                                                        {showSuggestions && activeSenderIndex === index && (
                                                            <div
                                                                ref={suggestionRef}
                                                                className={`absolute z-[100] w-full mt-1 max-h-48 overflow-y-auto rounded-xl border shadow-xl animate-in fade-in slide-in-from-top-1 ${'bg-white dark:bg-[#1a1a1a] border-gray-100 dark:border-[#333]'}`}
                                                            >
                                                                {suggestions.map((person) => (
                                                                    <div
                                                                        key={person.id}
                                                                        onClick={() => selectSuggestion(person.name)}
                                                                        className="px-4 py-3 text-xs font-bold uppercase tracking-wider cursor-pointer hover:bg-orange-50 dark:hover:bg-orange-900/10 hover:text-orange-600 transition-colors border-b last:border-0 border-gray-50 dark:border-white/5 flex items-center gap-3"
                                                                    >
                                                                        <User className="w-3 h-3 text-orange-400" />
                                                                        <span>{person.name}</span>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        )}

                                                        {!isValid && sender && (
                                                            <div className="absolute right-12 top-1/2 -translate-y-1/2 text-red-500 flex items-center gap-1 animate-in fade-in zoom-in">
                                                                <AlertCircle className="w-4 h-4" />
                                                            </div>
                                                        )}
                                                        {formData.senders.length > 1 && (
                                                            <button
                                                                onClick={() => removeSender(index)}
                                                                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-red-50 dark:bg-red-900/10 text-red-500 hover:bg-red-500 hover:text-white transition-all shadow-sm"
                                                            >
                                                                <Trash2 className="w-4 h-4" />
                                                            </button>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </div>

                                        <button
                                            onClick={addSender}
                                            className={`flex items-center gap-2 px-4 py-2 rounded-xl border-2 border-dashed ${'border-slate-100 dark:border-[#333] text-slate-400 hover:border-orange-500/30 hover:text-orange-600'} transition-all`}
                                        >
                                            <Plus className="w-4 h-4" />
                                            <span className="text-[10px] font-black uppercase tracking-widest">Add another sender</span>
                                        </button>
                                    </div>}

                                    {/* Regarding */}
                                    {canSummaryField && <div className="space-y-3">
                                        <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center justify-between gap-2">
                                            <div className="flex items-center gap-2">
                                                <MessageSquare className={`w-3 h-3 ${subTextColor}`} /> Regarding (Re:)
                                            </div>
                                            <span className="text-[9px] text-red-500 font-black tracking-widest">REQUIRED</span>
                                        </label>
                                        <textarea
                                            rows={4}
                                            placeholder="Enter letter summary"
                                            value={formData.regarding}
                                            onChange={(e) => setFormData({ ...formData, regarding: e.target.value })}
                                            className={`w-full px-6 py-4 ${inputBg} border-2 rounded-2xl focus:border-orange-500 focus:bg-white dark:focus:bg-white/10 transition-all text-lg font-medium outline-none resize-none`}
                                        />
                                    </div>}

                                    <div className="space-y-10">
                                        {/* Requested Date */}
                                        {/* This section is removed as per instruction */}

                                        {/* Encoder */}
                                        {canEncoderField && <div className="space-y-4 pt-4 border-t border-slate-50 dark:border-white/5">
                                            <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <User className={`w-3 h-3 ${subTextColor}`} /> Encoder Name (LASTNAME, FIRSTNAME)
                                                </div>
                                                <div className="flex items-center gap-4">
                                                    <span className="text-[9px] text-red-500 font-black tracking-widest">REQUIRED</span>
                                                </div>
                                            </label>
                                            <div className="relative">
                                                <input
                                                    type="text"
                                                    value={formData.encoder}
                                                    onChange={(e) => {
                                                        const val = e.target.value;
                                                        setFormData({ ...formData, encoder: val });
                                                        setActiveSenderIndex('encoder');
                                                        fetchSuggestions(val.split(',').pop().trim());
                                                    }}
                                                    onFocus={() => {
                                                        setActiveSenderIndex('encoder');
                                                        if (formData.encoder.length >= 2) fetchSuggestions(formData.encoder.split(',').pop().trim());
                                                    }}
                                                    className={`w-full px-6 py-4 border-2 rounded-2xl focus:border-orange-500 focus:bg-white dark:focus:bg-white/10 transition-all text-sm font-black uppercase tracking-wider outline-none ${!validateFormat(formData.encoder) ? 'border-red-500/50' : ''} ${'bg-slate-50 dark:bg-white/5 border-slate-100 dark:border-[#333] text-slate-600 dark:text-slate-200'}`}
                                                />

                                                {showSuggestions && activeSenderIndex === 'encoder' && (
                                                    <div
                                                        ref={suggestionRef}
                                                        className={`absolute z-[100] w-full mt-1 max-h-48 overflow-y-auto rounded-xl border shadow-xl animate-in fade-in slide-in-from-top-1 ${'bg-white dark:bg-[#1a1a1a] border-gray-100 dark:border-[#333]'}`}
                                                    >
                                                        {suggestions.map((person) => (
                                                            <div
                                                                key={person.id}
                                                                onClick={() => selectSuggestion(person.name)}
                                                                className="px-4 py-3 text-xs font-bold uppercase tracking-wider cursor-pointer hover:bg-orange-50 dark:hover:bg-orange-900/10 hover:text-orange-600 transition-colors border-b last:border-0 border-gray-50 dark:border-white/5 flex items-center gap-3"
                                                            >
                                                                <User className="w-3 h-3 text-orange-400" />
                                                                <span>{person.name}</span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                                {!validateFormat(formData.encoder) && (
                                                    <div className="absolute right-4 top-1/2 -translate-y-1/2 text-red-500 flex items-center gap-1">
                                                        <AlertCircle className="w-4 h-4" />
                                                    </div>
                                                )}
                                            </div>
                                            {/* Letter Kind - This section is removed as per instruction */}
                                        </div>}
                                    </div>
                                </div>
                            </section>
                        </div>

                        {/* Attachment Section */}
                        <div className="lg:col-span-4 space-y-8 md:space-y-12">
                            <section className={`${cardBg} p-8 md:p-16 rounded-[2.5rem] md:rounded-[3.5rem] border shadow-2xl flex flex-col`}>
                                <div className={`flex items-center gap-4 border-b pb-2 mb-10 ${'border-slate-50 dark:border-[#222]'}`}>
                                    <Upload className={`w-6 h-6 ${subTextColor}`} />
                                    <h2 className={`text-lg font-black uppercase tracking-tight ${textColor}`}>Attachments</h2>
                                </div>

                                {(() => {
                                    const selectedAtt = refAttachments.find(att => String(att.id) === String(formData.refAttachmentId));
                                    const attName = selectedAtt?.attachment_name?.toLowerCase() || "";
                                    const isLetterOrPhoto = attName.includes("letter") || attName.includes("photo");

                                    return (
                                        <div className="space-y-8">
                                            {/* Physical Attachment Selection - Moved Above Upload */}
                                            {canAttachmentSelector && <div className="space-y-3 pt-0 border-t border-slate-50 dark:border-white/5">
                                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                                                    Physical Attachment / Reference
                                                </label>
                                                <select
                                                    value={formData.refAttachmentId}
                                                    onChange={(e) => setFormData({ ...formData, refAttachmentId: e.target.value })}
                                                    className={`w-full px-4 py-3 rounded-2xl border-2 transition-all outline-none text-sm font-bold ${'bg-slate-50 dark:bg-white/5 border-slate-100 dark:border-[#333] focus:border-orange-500'}`}
                                                >
                                                    <option value="">-- Select Physical Attachment --</option>
                                                    {refAttachments.map(att => (
                                                        <option key={att.id} value={att.id}>
                                                            {att.attachment_name}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>}

                                            {/* Digital Upload - Disabled if not Letter/Photo */}
                                            {canAttachmentUpload && <div className={`space-y-6 transition-all duration-300 ${!isLetterOrPhoto ? 'opacity-60 grayscale-[0.5] pointer-events-none select-none' : ''}`}>
                                                <div className="flex items-center justify-between">
                                                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Scanned Letter Upload</h4>
                                                    {!isLetterOrPhoto && (
                                                        <span className="text-[9px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 dark:bg-amber-900/10 px-2 py-0.5 rounded border border-amber-500/20">
                                                            Required: Physical Attachment (Letter/Photo)
                                                        </span>
                                                    )}
                                                </div>
                                                <div
                                                    onClick={() => isLetterOrPhoto && fileInputRef.current.click()}
                                                    onDragOver={(e) => e.preventDefault()}
                                                    onDrop={(e) => isLetterOrPhoto && handleDrop(e)}
                                                    className={`flex-1 flex flex-col items-center justify-center border-2 border-dashed rounded-[1.5rem] md:rounded-[2rem] p-8 md:p-12 transition-all group ${!isLetterOrPhoto ? 'cursor-not-allowed border-slate-200 dark:border-[#222] bg-slate-50/30' : 'cursor-pointer border-slate-100 dark:border-[#333] bg-slate-50/50 dark:bg-white/5 hover:bg-orange-50 dark:hover:bg-orange-900/5'}`}
                                                >
                                                    <input
                                                        type="file"
                                                        multiple
                                                        disabled={!isLetterOrPhoto}
                                                        className="hidden"
                                                        ref={fileInputRef}
                                                        onChange={handleFileChange}
                                                    />
                                                    <div className={`w-20 h-20 bg-white dark:bg-white/10 rounded-full flex items-center justify-center shadow-lg mb-6 ${isLetterOrPhoto ? 'group-hover:scale-110' : ''} transition-transform`}>
                                                        <Upload className={`w-8 h-8 ${isLetterOrPhoto ? subTextColor : 'text-slate-300'}`} />
                                                    </div>
                                                    <h3 className={`text-sm font-black uppercase tracking-widest mb-1 ${isLetterOrPhoto ? textColor : 'text-slate-400'}`}>
                                                        {isLetterOrPhoto ? 'Click to Upload' : 'Upload Restricted'}
                                                    </h3>
                                                    <p className="text-xs text-slate-400 font-medium">
                                                        {isLetterOrPhoto ? 'or drag and drop files here' : 'Only for Letter or Photo types'}
                                                    </p>
                                                </div>

                                                {isLetterOrPhoto && attachments.length > 0 && (
                                                    <div className="mt-8 space-y-2">
                                                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Attached Files ({attachments.length})</h4>
                                                        <div className="max-h-40 overflow-y-auto pr-2 space-y-2 custom-scrollbar">
                                                            {attachments.map((file, index) => (
                                                                <div key={index} className={`flex items-center justify-between p-3 rounded-xl border group ${'bg-slate-50 dark:bg-white/5 border-slate-100 dark:border-[#333]'}`}>
                                                                    <div className="flex items-center gap-3 truncate">
                                                                        <div className={`w-8 h-8 bg-white dark:bg-white/10 border rounded-lg flex items-center justify-center ${subTextColor} ${'border-slate-100'}`}>
                                                                            <FileText className="w-4 h-4" />
                                                                        </div>
                                                                        <span className={`text-xs font-bold truncate ${textColor}`}>{file.name}</span>
                                                                    </div>
                                                                    <button
                                                                        onClick={(e) => {
                                                                            e.stopPropagation();
                                                                            removeAttachment(index);
                                                                        }}
                                                                        className="p-1.5 text-slate-300 hover:text-red-500 transition-colors"
                                                                    >
                                                                        <Trash2 className="w-4 h-4" />
                                                                    </button>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>}
                                        </div>
                                    );
                                })()}

                                <div className="mt-12 space-y-4">
                                    {canSubmit && (
                                        <button
                                            onClick={handleSend}
                                            className={`w-full py-5 ${accentColor} text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl active:scale-[0.98] ${'shadow-orange-100'}`}
                                        >
                                            <Send className="w-4 h-4" /> Send Letter
                                        </button>
                                    )}
                                    {canClear && (
                                        <button
                                            onClick={handleClear}
                                            className={`w-full py-5 bg-transparent border-2 font-black text-xs uppercase tracking-[0.2em] rounded-2xl flex items-center justify-center gap-3 transition-all ${'border-slate-100 dark:border-[#333] text-slate-400 hover:border-red-100 dark:hover:border-red-900/20 hover:text-red-500'}`}
                                        >
                                            <Trash2 className="w-4 h-4" /> Clear All Fields
                                        </button>
                                    )}
                                </div>
                            </section>
                        </div>

                    </div>
                </main>

                {/* Modern Footer Branding */}
                <footer className={`h-auto md:h-16 py-6 md:py-0 ${headerBg} border-t px-4 md:px-12 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] font-black text-slate-400 uppercase tracking-widest`}>
                    <span>&copy; 2026 LMS 2.0</span>

                </footer>
            </div>

            <SuccessModal
                isOpen={isSuccessModalOpen}
                isGuest={!user?.id || user?.isGuest}
                onClose={async () => {
                    setIsSuccessModalOpen(false);
                    handleClear();
                    // Refresh the next reference number
                    try {
                        const preview = await letterService.getPreviewIds();
                        if (preview?.lms_id) setReferenceNo(preview.lms_id);
                    } catch { }
                }}
                referenceNo={referenceNo}
            />

            {/* Exit Confirmation Modal */}
            <SuccessModal
                variant="confirm"
                isOpen={isExitModalOpen}
                onClose={() => setIsExitModalOpen(false)}
                title="Exit Guest Mode?"
                message="Your unsaved letter will be discarded. You will be returned to the login page."
                confirmLabel="Exit"
                cancelLabel="Stay"
                onConfirm={() => {
                    setIsExitModalOpen(false);
                    logout();
                    navigate('/login');
                }}
            />
        </div>
    );
}
